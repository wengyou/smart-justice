import React from 'react';
import './index.scss';

const Footer = () => {
    return (
        <div className='flex center footer'>
            @版权所有重庆邮电大学智慧司法团队
        </div>
    )
};

export default Footer;