import React, {useEffect, useState} from 'react';
import { Upload, message, Input, List ,Checkbox, Button  } from 'antd';
import { InboxOutlined, RightOutlined } from '@ant-design/icons';
import './upload.scss'


const { Dragger } = Upload;
const { TextArea } = Input;
const { Search } = Input;
const CheckboxGroup = Checkbox.Group;
const plainOptions = ['责任划分', '伤害赔偿范围', '交通事故认定书', '伤情/死亡相关性', '鉴定意见书', '财产赔偿范围'];

const propsUpload = {
    name: 'file',
    multiple: true,
    action: 'https://www.mocky.io/v2/5cc8019d300000980a055e76',
    onChange(info) {
      const { status } = info.file;
      if (status !== 'uploading') {
        console.log(info.file, info.fileList);
      }
      if (status === 'done') {
        message.success(`${info.file.name} file uploaded successfully.`);
      } else if (status === 'error') {
        message.error(`${info.file.name} file upload failed.`);
      }
    },
  };
const UploadCom = (props) => {
    const [left, setLeft] = useState([]);
    const [right, setRight] = useState([]);
    const onChange = info => {
        const { status } = info.file;
        if (status !== 'uploading') {
            console.log(info.file, info.fileList);
        }
        if (status === 'done') {
            const res = info.file.response.data;
            console.log(res);
            let _left=[],_right = [];
            res.原告诉称.forEach((el,i) => _left.push(i+1 + '. ' + el.item));
            res.被告辩诉.forEach((el,i) => _right.push(i+1 + '. ' + el.item));
            setLeft(_left);
            setRight(_right);
            message.success(`${info.file.name} 上传成功.`);
        } else if (status === 'error') {
            message.error(`${info.file.name} 上传失败.`);
        }
    };
    const [flag, setFlag] = useState('upload');
    useEffect(() => {
        flag === 'disputeDetail' && props.parent(flag);
    }, [flag]);
    return(
        <div className='dispute-container'>
            <div className='upload' >
                <Dragger 
                    {...propsUpload}
                    // onChange={onChange}
                >
                    <p className="ant-upload-drag-icon">
                        <InboxOutlined />
                    </p>
                    <p className="ant-upload-text">点击将文件拖拽到这里上传</p>
                    <p className="ant-upload-hint">
                        支持拓展名为 .docx、.txt
                    </p>
                </Dragger>
            </div>
            <div className='content'>
                <List
                    header={<div>原告诉称:</div>}
                    bordered
                    dataSource={left}
                    style={{width: '48%'}}
                    renderItem={item => (
                        <List.Item>
                            {item}
                        </List.Item>
                    )}
                />
                <List
                    header={<div>被告辩诉:</div>}
                    bordered
                    dataSource={right}
                    style={{width: '48%'}}
                    renderItem={item => (
                        <List.Item>
                            {item}
                        </List.Item>
                    )}
                />
            </div>
            <Search
                placeholder="请输入案件ID"
                enterButton="确定"
                size="small"
                onSearch={value => console.log(value)}
                style={{marginLeft: '50vw', width: '20vw', marginTop: '10px'}}
            />
            <div className='select'>
                <div className="site-checkbox-all-wrapper">
                    <Checkbox>
                        全选
                    </Checkbox>
                    <CheckboxGroup
                    options={plainOptions}/>
                </div>
            </div>
            <Button 
                type="link" 
                className='see'
                onClick={() => {setFlag('disputeDetail')}}
            >
                查看争议焦点
                <RightOutlined />
            </Button>
        </div>
    )
}

export default UploadCom;