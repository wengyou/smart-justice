import React, {useEffect, useState} from 'react';
import { Table } from 'antd';
import { InboxOutlined, RightOutlined } from '@ant-design/icons';
import './sameCase.scss'

const SameCase = props => {
    return(
        <div className="sameCase-container">
            <p>相似案例</p>
            <Table />
        </div>
    )
}

export default SameCase;