import React from 'react';
import { Link, useHistory } from 'react-router-dom';
import { Button } from 'antd';
import {DownOutlined} from '@ant-design/icons';
import './index.scss'

const Header = () => {
    let history = useHistory();
    return (
        <div className='font_white bg_blue header bold shadow flex center_column'>
            <p>智 慧 司 法</p>
            <span 
                className='eSpace' 
                // onClick={() => history.push('/enterprise')}
            >
                企业空间 
                <DownOutlined style={{marginLeft: "5px"}} />
            </span>
            <span className='pSpace'>个人空间</span>
        </div>
    )
};

export default Header;