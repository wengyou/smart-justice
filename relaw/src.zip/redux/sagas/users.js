import {takeEvery, put, call} from "redux-saga/effects";
import Service from '../../utils/Servise';
import { message } from 'antd';
import {
    USER_LOGIN,
    USER_REGISTER,
    TOGGLE_LOADING_ON,
    TOGGLE_LOADING_OFF,
} from '../actionTypes';

function *login(args){
    try {
        yield put({ type: TOGGLE_LOADING_ON});
        const res = yield call(Service.post, '/user/login', args.args);
        yield put({ type: TOGGLE_LOADING_OFF});
        if(res.data.status === 200){
            message.success('登陆成功！！');
            localStorage.setItem('username', args.args.username);
        } else {
            message.error(res.data.msg);
        }
    } catch (e) {

    }
}

function *register(args){
    try {
        yield put({ type: TOGGLE_LOADING_ON});
        const res = yield call(Service.post, '/user/register', args.args);
        yield put({ type: TOGGLE_LOADING_OFF});
        if(res.data.status === 200){
            message.success('登陆成功！！');
            localStorage.setItem('username', args.args.username);
        } else {
            message.error(res.data.msg);
        }
    } catch (e) {

    }
}

export default function *rootUsers(){
    yield takeEvery(USER_LOGIN, login);
    yield takeEvery(USER_REGISTER, register);
}