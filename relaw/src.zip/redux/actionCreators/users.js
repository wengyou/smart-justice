import { 
    USER_LOGIN, USER_REGISTER
} from '../actionTypes.js';

export const login = args => ({
    type: USER_LOGIN,
    args
});

export const register = args => ({
    type: USER_REGISTER,
    args
})