//公共部分

//切换loading状态
export const TOGGLE_LOADING_ON = 'TOGGLE_LOADING_ON';
export const TOGGLE_LOADING_OFF = 'TOGGLE_LOADING_OFF';

//用户登陆
export const USER_LOGIN = 'USER_LOGIN'
export const USER_LOGIN_OK = 'USER_LOGIN_OK'

//用户注册
export const USER_REGISTER = 'USER_REGISTER';
export const USER_REGISTER_OK = 'USER_REGISTER_OK';







