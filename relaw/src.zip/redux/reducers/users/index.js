import { 
    USER_LOGIN_OK
 } from '../../actionTypes'

const defaultState = {
    name: '',
    token: ''
};

export default (state = defaultState, action) => {
    switch(action.type) {
        case USER_LOGIN_OK:
            return {
                ...state,
            };

        default:
            return state;
    }  
};